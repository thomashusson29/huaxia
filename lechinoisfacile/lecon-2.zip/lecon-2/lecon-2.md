# Leçon 2

Source : <https://www.lechinoisfacile.fr/cours/lecons-gratuites/lecon/lecon-2/>

# 第二课

# dì èr kè

<audio controls src="audio/ordre_0_2_numlecon_new.mp3"></audio>

# Les variantes des traits de base

Vous avez appris avec moi dans la leçon précédente à tracer 6 traits de base et à dessiner les 3 caractères 林 十 人. J’en suis ravie.

Je suis surprise que tout le monde soit arrivé à les tracer avec moi. C’est la première fois dans votre vie, j’imagine. J’aimerais vous faire remarquer ceci: Ce que vous avez accompli en cours d’hier représente quasiment un pas de géant vers la lune ! Vous allez comprendre plus tard pourquoi je vous dis ça. Je pèse mes mots.

En effet les Français n’ont pas eu tort de trouver le chinois difficile comme langue. Cette perception tient au fait que le chinois n’est pas une langue alphabétique contrairement aux langues occidentales! On l’a vu dans la leçon précédente, les Chinois tracent des traits pour écrire. A titre de rappel les traits sont les équivalents de vos lettres de l’alphabet. En revanche par manque de bonne approche dans des écoles ou dans d’autres organismes de formation, il est normal que votre perception persiste depuis des lustres, parce que l’on ne savait pas commencer par où et comment s’y prendre.

Le chinois est une langue pictographique et idéographique, l’une des particularités marquantes du chinois. Cela exige, à mon sens, la mise en œuvre d’une autre méthode et d’une autre approche qui soient efficaces pour rendre le chinois enfin facile à apprendre.

Certains enseignants et certains élèves de chinois ont eu tort de comparer le chinois avec les langues occidentales. Le chinois est fondamentalement différent de par sa façon d’écrire et sa logique. Je vous propose de me suivre en implantant de nouveaux réflexes et formatant votre cerveau à la chinoise dès à présent -) (juste quand vous êtes en cours avec moi).

L’appréhension de ne pas arriver à écrire comme les Chinois n’aura pas lieu d’exister avec ma méthode que je qualifié de révolutionnaire. Vous allez vous rendre compte que ce n’est pas si compliqué de savoir écrire comme les Chinois au bout de quelques leçons. Vous allez étonnement constater dans les prochaines leçons que votre progrès aura été énorme.

Les 6 traits de base constituant le fondement de l’écriture chinoise, vous aurez à cœur de vous entraîner à les tracer. Le fait de savoir les tracer vous facilitera incroyablement votre apprentissage pour tracer les variantes et surtout pour écrire les caractères plus tard.

Veuillez noter qu’apprendre à écrire a pour but de faciliter plus tard votre oral et d’obtenir le résultat plus vite et plus aisément.

On va revoir avant toute chose les 6 traits de base avant d’apprendre les variantes :

![ordre_1_Lecon2_1_trait_de_base](images/ordre_1_Lecon2_1_trait_de_base-p8o26idi693whod77ihievk1uwhx7gnyv5fzdbtbos.jpg)

Comme les 6 traits de base ne suffisent pas à composer tous les caractères chinois, les Chinois ont créé des variantes à partir des 6 traits de base. Il en existe une vingtaine.

Parmi celles-ci :

![ordre_2_Lecon2_2_variante](images/ordre_2_Lecon2_2_variante-p8o27z0gsz3yju8qo58mai9v4hah6igxqdz68tnae8.jpg)

S’agissant des successions de traits de base, les variantes sont les combinaisons issues de 6 traits de base.

Ne vous inquiétez pas, il n’est absolument pas nécessaire de savoir comment ça se dit, ces variantes.

Exemples :

-Le caractère 马 qui signifie “cheval” est composé de 3 traits : 2 variantes et le trait horizontal. Il représente un cheval stylisé.

![ordre_3_Lecon2_3_-decomposition](images/ordre_3_Lecon2_3_-decomposition-p8o29691jcr5dwhxnnxgh7d2g7dd0l8l8bzibjv62y.jpg)

<audio controls src="audio/ordre_1_Lecon2_1_ma3.mp3"></audio>

-Le caractère 口 qui signifie “bouche” est composé de 3 traits : le trait vertical, 1 variante et le trait horizontal. Il représente une bouche ouverte stylisée.

![ordre_4_Lecon2_4_-decomposition](images/ordre_4_Lecon2_4_-decomposition-p8o2bxvxnsjjkkh7huzwti7xf1q9oi84y14z6vrfre.jpg)

<audio controls src="audio/ordre_2_Lecon2_2_kou3.mp3"></audio>

-Le caractère 尔 qui signifie “tu” est composé de 5 traits. Il s’agit d’une forme ancienne de “tu”. Aujourd’hui, le caractère pour dire “tu” est légèrement différent.

![ordre_5_Lecon2_5_-decomposition](images/ordre_5_Lecon2_5_-decomposition.jpg)

<audio controls src="audio/ordre_3_Lecon2_3_er3.mp3"></audio>

Vous apprendrez toutes les variantes au fil des leçons.

![Image](images/dragon.png)

Note culturelle : Comme les 6 traits de base ne suffisent pas à composer tous les caractères, nos ancêtres ont créé les variantes.
En chinois il existe environ 10 000 caractères parmi lesquels 1 000 sont les plus courants. Rassurez-vous, vous n’aurez pas besoin de connaître 10 000 caractères pour arriver à communiquer. 1 000 caractères et mots vous suffiront pour que vous puissiez vous débrouiller dans des différentes situations.
A l’issue du programme Pack Complet (107 leçons) au bout d’un an d’apprentissage vous aurez appris approximativement 1 800 caractères et mots.
Cela va très vite, vous ne pouvez pas imaginer. Vous avancerez inconsciemment vite, zen. Cool, non ?

# EXERCICES

Et maintenant, c’est à vous ! Voici votre deuxième exercice de l’écriture chinoise.

Imprimez les pages d’écriture téléchargeables et entraînez-vous à tracer les 13 variantes ainsi que les caractères que vous avez appris aujourd’hui : 马, 口 et 尔.

Ecrivez chacun d’eux 5 fois en respectant bien l’ordre et le sens des traits.

A titre indicatif: Chaque variante doit être tracée en une seule fois, sans lever le crayon lors du changement de la direction du trait.

Ce que vous avez à faire c’est me suivre pas à pas. Tout le monde va y arriver.

Limite de Temps: 0

#### Résumé de Quiz

0 of 3 Questions completed

Questions:

#### Information

You have already completed the quiz before. Hence you can not start it again.

Quiz is loading…

You must sign in or sign up to start the quiz.

Vous devez d’abord complété le suivant :

#### Résultats

Quiz complete. Results are being recorded.

#### Résultats

0 of 3 Questions answered correctly

Your time:

Temps écoulé

You have reached 0 of 0 point(s), (0)

Earned Point(s): 0 of 0, (0)
0 Essay(s) Pending (Possible Point(s): 0)

#### Catégories

- Pas classé 0%

-

- 1

- 2

- 3

- Current

- Révision

- Répondu

- Exact

- Inexact

- Question 1 of 3

##### 1. Question

### Choisissez la bonne réponse.

Les variantes sont-elles issues des 6 traits de base ?

- [ ] Oui

- [ ] Non

- [ ] 不知道 (je ne sais pas)

Exact Inexact

- Question 2 of 3

##### 2. Question

### Choisissez la bonne réponse.

Combien de variantes existe-t-il dans le caractère 马 ?

- [ ] Une

- [ ] Deux

- [ ] Trois

- [ ] 不知道 (je ne sais pas)

Exact Inexact

- Question 3 of 3

##### 3. Question

### Associez chaque caractère avec sa signification.

1) 十 2) 人 3) 木 4) 马 5) 口

-

Homme : ______

Cheval : ______

Dix : ______

Bouche : ______

Arbre : ______

Exact Inexact
