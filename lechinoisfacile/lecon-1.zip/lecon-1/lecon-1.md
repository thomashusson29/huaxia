# Leçon 1

Source : [Le Chinois Facile](https://www.lechinoisfacile.fr/cours/lecons-gratuites/lecon/lecon-1/)

![Meifen Chen](images/PhotoMeifenChen2-p79rof2xd1cetz3a38d5qz826o7d8az4a0dlm29hoq.jpg)

Je suis Meifen CHEN, créatrice de la méthode **révolutionnaire Le Chinois Facile** et professeur/formatrice de chinois renommée en Ile-de-France depuis 2003, conceptrice des 107 leçons réparties en 4 formules élaborées en fonction des programmes respectifs. Bienvenue dans mes cours de chinois en ligne.

Avec ma méthode **protégée par l’INPI** – **innovante**, **unique**, **efficace**, ludique, inspirante et adaptée à chaque élève, vous allez apprendre **facilement** et **rapidement** à écrire, à parler et à lire le chinois et vous aurez acquis 3 compétences en même temps.

En tant que créatrice de la méthode et spécialiste dans l’enseignement et la formation du chinois depuis 2003 j’applique ma propre méthode. Elle a déjà **fait ses preuves** auprès de tous mes élèves depuis sa création.

Avec l’accélération numérique liée à la pandémie on est enfin arrivés au bout des années de **développement titanesque**, à mettre ma méthode et mes cours de chinois en ligne à la disposition d’un public beaucoup plus large et j’ai la fierté de vous en faire bénéficier désormais.

Je considère qu’il est **primordial** de prendre d’emblée connaissance de **quelques éléments de base** pour démarrer **sûrement** et **sereinement** votre apprentissage, ce qui est le **gage** de **votre réussite**.

Ces éléments de base sont comme une **clé** vous permettant d’**entrer dans le monde** de la langue chinoise qui vous paraît encore **indéchiffrable** et **mystique** en raison des particularités inhérentes du chinois qui constituent **des zones d’ombre** jusqu’à ce jour. Je vais commencer par vous dévoiler son **arcane** en écriture avec **mon approche** révolutionnaire. C’est **du jamais vu** sur le marché du point de vue de la **valeur** que représente mon approche.

Grâce à **l’ingéniosité** de ma pédagogie vous allez apprendre **en toute simplicité** et **en toute facilité** plus de 2 000 caractères et mots répertoriés par HSK1-3 correspondants aux A1, A2 et B1 de CCERL (Cadre commun européen de référence pour les langues) avec la formule **Pack Complet**, **solution optimale** à l’issue d’un an d’apprentissage.

J’ai déjà **révolutionné** la façon d’apprendre chinois de tous mes anciens élèves en cours physiques depuis 2003 et je vais révolutionner **la vôtre** désormais (Chacun de mes mots ci-dessus sont pesés).

Lisez les textes, écoutez les audio, **répétez après moi** autant que vous le pouvez pour que vos oreilles soient imbibées de la consonance du chinois. Suivez-moi **pas à pas** et faites bien tous les exercices, vous serez étonnés de vos **progrès rapides**.

À la fin de chaque leçon, vous cliquez sur le bouton **VALIDER LES RÉPONSES** pour vérifier vos réponses en cliquant sur le bouton **VOIR LES BONNES RÉPONSES**.

Êtes-vous prêts ? Commençons tout de suite !!!

## 第一课

## dì yī kè

<audio controls src="audio/ordre_0_1_numlecon_new.mp3"></audio>

## Les 6 traits de base

Aujourd’hui, nous allons commencer par les **6 traits de base** qui sont le **fondement** de l’écriture chinoise. Sans quoi le chinois n’a pas lieu d’exister. C’est une langue mélodieuse et esthétique du point de vue de sa représentation graphique. Mais rassurez-vous, les Chinois considèrent le français comme étant des plus belles au monde.

Comme la langue chinoise est une langue **pictographique** et **idéographique**, les Chinois tracent des **traits** pour écrire.

Les traits sont des **tracés** que tracent les Chinois dans un **sens prédéfini**. Du point de vue de leur fonction les traits sont **les équivalents** des lettres de l’alphabet dans les langues occidentales.

Dans l’écriture chinoise on ne dénombre que **6 traits** que je nomme « **de base** » alors que dans les langues occidentales il existe **26 lettres**. Les voici :

![Les six traits de base](images/Lecon1_1_trait_de_base-p70xs7gw7ay9vijbn3nke8x73a2qqrfmxyo00ogt4c.jpg)

Par exemple : 木 qui veut dire « **arbre** » et 林 qui veut dire « **forêt** ».

Le caractère 木 est composé de 4 traits :

![Décomposition de 木](images/Lecon1_2_decomposition-p70xtlac9iugyuiyk76skecmkp972pxest8qgcexzo.jpg)

Dans 木 le **trait vertical** du milieu représente le tronc de l’arbre et ceux des deux côtés représentent ses **branches**. De ce point de vue je qualifie le chinois de **pictographique**.

Pour les Chinois, 2 arbres font la forêt 林 ! De ce point de vue je qualifie le chinois **d’idéographique**.

C’est facile à comprendre comme idée, non ?

### Le 1er trait : héng

![Le trait héng](images/Lecon1_3_heng2.png)

<audio controls src="audio/ordre_1_Lecon1_1_heng2.mp3"></audio>

**héng** : il s’agit d’un tracé **horizontal**, on le trace **de gauche à droite**.

### Le 2ème trait : shù

![Le trait shù](images/ordre_5_Lecon1_4_shu4-150x150.png)

<audio controls src="audio/ordre_2_Lecon1_2_shu4.mp3"></audio>

**shù** : il s’agit d’un tracé vertical, on le trace de haut en bas.

Avec ces 2 premiers traits on peut déjà écrire notre 1er caractère : 十 shí = « **dix** ».

![Décomposition de 十](images/ordre_6_Lecon1_5_decomposition-p70y4dhoo3lw5sv2lczpo6dzwu3sdpqjy6o9nmfcnk.jpg)

<audio controls src="audio/Lecon1_3_shi2.mp3"></audio>

### Le 3ème trait : diǎn

![Le trait diǎn](images/ordre_7_Lecon1_6_dian.png)

<audio controls src="audio/ordre_4_Lecon1_4_dian3.mp3"></audio>

**diǎn** : c’est un petit bout. On le trace **de haut en bas** comme l’accent grave en français.

### Le 4ème trait : tí

![Le trait tí](images/ordre_8_Lecon1_7_ti.png)

<audio controls src="audio/ordre_5_Lecon1_5_ti2.mp3"></audio>

**tí** : il s’agit d’un petit tracé **vers le haut**, mais plus long que **diǎn 丶**.

### Le 5ème trait : piě

![Le trait piě](images/ordre_9_Lecon1_8_pie.png)

<audio controls src="audio/ordre_6_Lecon1_6_pie3.mp3"></audio>

**piě** : il s’agit d’une petite courbe **inclinée vers la gauche**.

### Le 6ème trait : nà

![Le trait nà](images/ordre_10_Lecon1_9_na.png)

<audio controls src="audio/ordre_7_Lecon1_7_na4-1.mp3"></audio>

**nà** : il s’agit d’une petite courbe **inclinée vers la droite**.

Avec ces 2 derniers traits, on peut déjà écrire notre 2ème caractère 人 rén = « **homme** ».

![Décomposition de 人](images/ordre_11_Lecon1_10_decomposition-p70ylmt05l8fc1sktbk3yblokj1epn94nlw7viu4eo.png)

<audio controls src="audio/Lecon1_8_ren2.mp3"></audio>

Il représente un homme stylisé, debout sur ses deux jambes.

Vous voyez, c’est **beaucoup moins difficile** qu’il y paraît. À mon sens il est **fondamental** de savoir dessiner avec ces 6 traits de base qui sont les **équivalents** des lettres latines.

À part ces 6 traits de base, il existe une quinzaine de variantes que nous étudierons dans notre prochaine leçon. C’est un peu normal. En effet il existe 26 lettres en français pour composer des mots par dizaines de milliers.

À titre indicatif, vous n’avez pas forcément besoin de savoir prononcer l’intitulé de ces 6 traits de base. Ce qui compte pour vous c’est arriver à les dessiner. Cool, non ? :-)

**_Note culturelle_ :** D’après les fouilles archéologiques, les premiers caractères ont été gravés sur des carapaces de tortues et sur des lamelles de bambou. L’apparition des premiers caractères (ou sinogrammes) remonte à la dynastie des Shang il y a plus de 3 000 ans. Ces caractères mis au jour à la suite des fouilles archéologiques étaient très figuratifs. Ils représentaient graphiquement un **objet**, un **être humain** ou un **animal**.

![Dragon](images/dragon.png)

Par exemple **l’homme** que nous venons de voir :

![Évolution du caractère 人](images/ordre_12_Lecon1_11__evolution-p70ype5nu624bnvmmfi96gf05j7zcggvbak4m1eo6e.png)

Je veux vous démontrer à travers cette mise en bouche ce que représente **vraiment** le chinois, en quoi le chinois est **fondamentalement différent** des langues occidentales et en quoi notre **approche** pour aborder le chinois n’a rien à voir avec toutes les autres dans le paysage de l’enseignement du chinois en France, dans le seul but de faire réussir votre apprentissage du chinois. Il s’agit bien de remonter **de cette manière** à la source de la difficulté du chinois que constitue **l’écriture chinoise** qui prend la forme des *pattes de mouche* et fait peur.

Notre approche **inédite** dans laquelle réside la **valeur** de notre méthode.

Pour nous protéger d’être copiés par nos concurrents du marché on a déposé cette approche et notre méthode à **l’INPI** en 2012. Il s’agit bien d’une méthode **brevetée**. Il est à noter que vous n’avez absolument pas le droit de divulguer les informations qui s’y rapportent ici à des tiers ni les exploiter à des fins commerciales.

Vous avez aussi l’accès gratuit à la leçon 61, l’une des **107** pour vous démontrer comment une leçon **riche en contenu pertinent** se présente et à quel point notre savoir-faire **unique** en la matière et notre professionnalisme aussi **rarissime** que dévoué sont impliqués.

## EXERCICES

Commençons dès maintenant votre premier exercice de l’écriture chinoise.

Imprimez la page d’écriture et entraînez-vous à tracer les 6 traits de base et les 2 caractères que vous avez appris 十 et 人.

Écrivez chacun d’eux une dizaine de fois en respectant bien **l’ordre** et **le sens des traits**.

Il n’y a rien de plus **simple** pour tracer les 6 traits de base comme moi. Le héng (le 1er des 6 traits de base) se trace **de gauche à droite**. Le shù (le 2ème des 6 traits de base) se trace de **haut en bas**.

C’est très important ! Le sens et l’ordre des traits sont des *règles d’orthographe*. Si vous ne les respectez pas, les Chinois considéreront que vous avez brûlé un feu rouge !!!

### Choisissez la réponse juste.

Les traits de base sont-ils les équivalents des lettres de l’alphabet dans les langues occidentales ?

- Oui
- Non
- 不知道 (je ne sais pas)

Remettez à leur place les deux caractères que vous avez appris aujourd’hui. (Saisissez le chiffre correspondant à chaque caractère) :

1. 人
2. 十

En chinois le nombre 10 s’écrit : ______

En chinois l’homme s’écrit : ______

Pour être sincère avec vous, ce que vous avez accompli en ce jour revient à avancer un **pas de géant vers la lune**. Vous avez de quoi être fiers si vous êtes grand débutants ou faux-débutants.

Avec mon sens du professionnalisme j’ai pris le soin de mettre en place le **dispositif audio** pour chaque caractère, chaque mot, chaque phrase et du contenu complémentaire comme si vous étiez en cours physiques avec moi. **Par ingéniosité** j’ai ajouté dans les textes de leçon des **barres obliques** pour **faciliter** votre travail de répéter et votre compréhension comme vous allez le constater dans la leçon 61 à laquelle vous aurez également l’accès gratuit.

Vous aurez accès à vos cours **à vie** une fois votre formule acquittée. **Pack Complet-solution optimale** est le meilleur choix si vous avez 12 mois à consacrer. Vous n’aurez qu’à me suivre **pas à pas** pour préparer votre HSK ou votre voyage ou devenir vite **opérationnels**. Ce nouveau mode d’apprentissage vous permet d’apprendre **à votre rythme**, **où que vous soyez** et **à moindre coût**. Vous serez accompagnés tout au long de votre parcours via des groupes de discussion.

**L’efficacité prouvée** et **inégalée** auprès de tous nos élèves en cours physiques.

J’ai déjà **révolutionné** la façon d’apprendre le chinois de tous nos anciens élèves **en cours physiques** depuis 2003. Je vais révolutionner la vôtre.

J’imagine que cette leçon de découverte vous a convaincus et que vous avez hâte de démarrer. Je vous invite à cliquer sur [ce lien](https://www.lechinoisfacile.fr/formules-cours/) pour accéder à nos 4 formules vous permettant d’apprendre le chinois **facilement**, **rapidement** et **efficacement** avec notre méthode dont l’approche est **inédite**, **protégée par l’INPI**.

Je vous donne mon rendez-vous à la prochaine leçon.
